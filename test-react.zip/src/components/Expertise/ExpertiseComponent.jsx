import React from 'react'

// Imports
import Expertise from "./Expertise"

class ExpertiseComponent extends React.Component {
  render () {
    return <Expertise {...this.props} />
  }
}

export default ExpertiseComponent
