import React from 'react'

import Footer from "./Footer"

class FooterComponent extends React.Component {
  render () {
    return <Footer {...this.props} />
  }
}

export default FooterComponent
