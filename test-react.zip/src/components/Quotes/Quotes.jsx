import React from 'react'

import face_1_webp from "../../assets/images/photos/face-1.webp"
import face_2_webp from "../../assets/images/photos/face-2.webp"
import face_3_webp from "../../assets/images/photos/face-3.webp"
import face_4_webp from "../../assets/images/photos/face-4.webp"
import face_5_webp from "../../assets/images/photos/face-5.webp"

class Quotes extends React.Component {
  render () {
    return (
      <div className="quotes d-flex justify-content-center align-items-start pt-70 pb-70">
        <div className="container inner-quotes d-flex justify-content-center align-items-start row">
          <div className="title-wrapper w-100 d-flex justify-content-center align-items-start row pb-45 col-12">
            <h1 className="title ta-l p-0 pb-30 w-100">“</h1>
          <p className="sm-t p-0 white-sm-t">This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean<br />sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis<br />sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit. Nam nec tellus<br />a odio tincidunt auctor a ornare odio. Sed non  mauris vitae erat consequat auctor eu in elit.</p>
          </div>
          <div className="row d-flex justify-content-center">
            <p className="sm-t white-color pb-13 mb-0">JANE GALADRIEL</p>
            <p className="sm-t sm-subtitle pb-45 mb-0">CEO TENGKUREP</p>
          </div>
          <div className="photos d-flex justify-content-center overflow-sm-scroll">
            <img className="face" src={face_1_webp} alt="face-1 1" />
            <img className="face" src={face_2_webp} alt="face-2 2" />
            <img className="face" src={face_3_webp} alt="face-3 3" />
            <img className="face" src={face_4_webp} alt="face-4 4" />
            <img className="face" src={face_5_webp} alt="face-5 5" />
          </div>
        </div>
      </div>
    )
  }
}

export default Quotes
