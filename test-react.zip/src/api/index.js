import instance from "./basicalInstance.js"

export default instance
