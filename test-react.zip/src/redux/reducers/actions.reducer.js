import React from "react"

// Actions API
import API from "../../api/Actions"

import {
  IS_SEND_LOADING,
  IS_SEND_FAILED_LOADING,
  IS_SEND_LOADED,
  OPEN_VIDEO,
  CLOSE_VIDEO,
  OPEN_REVIEW,
  CLOSE_REVIEW
} from "../types/actions.js"

// Images
import semf_ucuk_webp from "../../assets/images/photos/semf_ucuk.webp"
import dik_adalin_webp from "../../assets/images/photos/dik_adalin.webp"
import jeng_kol_webp from "../../assets/images/photos/jeng_kol.webp"
import pet_romak_webp from "../../assets/images/photos/pet_romak.webp"

import work1 from "../../assets/images/works/work1.webp"
import work2 from "../../assets/images/works/work2.webp"
import work3 from "../../assets/images/works/work3.webp"
import work4 from "../../assets/images/works/work4.webp"
import work5 from "../../assets/images/works/work5.webp"
import work6 from "../../assets/images/works/work6.webp"
import work7 from "../../assets/images/works/work7.webp"
import work8 from "../../assets/images/works/work8.webp"
import work9 from "../../assets/images/works/work9.webp"
import work10 from "../../assets/images/works/work10.webp"
import work11 from "../../assets/images/works/work11.webp"
import work12 from "../../assets/images/works/work12.webp"

// Initial
let initialState = {
  data: null,
  loadings: {
    is_send_loading: false,
    is_open_video_winodw: false
  },
  reviews: [
    {
      id: 0,
      img: semf_ucuk_webp,
      name: "SEMF UCUK",
      profession: "CEO & FOUNDER",
      review: "Lorem ipsum dolor sit amet proin gravida nibh vel velit",
      is_open: false
    },
    {
      id: 1,
      img: dik_adalin_webp,
      name: "DIK ADALIN",
      profession: "ENGINEERING",
      review: "Lorem ipsum dolor sit amet proin gravida nibh vel velit",
      is_open: false
    },
    {
      id: 2,
      img: jeng_kol_webp,
      name: "JENG KOL",
      profession: "DESIGNER",
      review: "Lorem ipsum dolor sit amet proin gravida nibh vel velit",
      is_open: false
    },
    {
      id: 3,
      img: pet_romak_webp,
      name: "PET ROMAK",
      profession: "MARKETING",
      review: "Lorem ipsum dolor sit amet proin gravida nibh vel velit",
      is_open: false
    }
  ],
  works: [
    {
      id: 0,
      img: work1,
      name: "Lorem ipsum dolor sit amet proin gravida nibh vel velit"
    },
    {
      id: 1,
      img: work2,
      name: "Lorem ipsum dolor sit amet proin gravida nibh vel velit"
    },
    {
      id: 2,
      img: work3,
      name: "Lorem ipsum dolor sit amet proin gravida nibh vel velit"
    },
    {
      id: 3,
      img: work4,
      name: "Lorem ipsum dolor sit amet proin gravida nibh vel velit"
    },
    {
      id: 4,
      img: work5,
      name: "Lorem ipsum dolor sit amet proin gravida nibh vel velit"
    },
    {
      id: 5,
      img: work6,
      name: "Lorem ipsum dolor sit amet proin gravida nibh vel velit"
    },
    {
      id: 6,
      img: work7,
      name: "Lorem ipsum dolor sit amet proin gravida nibh vel velit"
    },
    {
      id: 7,
      img: work8,
      name: "Lorem ipsum dolor sit amet proin gravida nibh vel velit"
    },
    {
      id: 8,
      img: work9,
      name: "Lorem ipsum dolor sit amet proin gravida nibh vel velit"
    },
    {
      id: 9,
      img: work10,
      name: "Lorem ipsum dolor sit amet proin gravida nibh vel velit"
    },
    {
      id: 10,
      img: work11,
      name: "Lorem ipsum dolor sit amet proin gravida nibh vel velit"
    },
    {
      id: 11,
      img: work12,
      name: "Lorem ipsum dolor sit amet proin gravida nibh vel velit"
    }
  ]
}

// Types
const actionsReducer = (state = initialState, action) => {

  switch (action.type) {
    case IS_SEND_LOADING:
      return {
        ...state,
        loadings: {
          ...state.loadings,
          is_send_loading: true
        }
      }
    case IS_SEND_FAILED_LOADING:
      return {
        ...state,
        loadings: {
          ...state.loadings,
          is_send_loading: false
        }
      }
    case IS_SEND_LOADED:
      return {
        ...state,
        data: action.data,
        loadings: {
          ...state.loadings,
          is_send_loading: false
        }
      }
    case OPEN_VIDEO:
      return {
        ...state,
        loadings: {
          ...state.loadings,
          is_open_video_winodw: true
        }
      }
    case CLOSE_VIDEO:
      return {
        ...state,
        loadings: {
          ...state.loadings,
          is_open_video_winodw: false
        }
      }
    case OPEN_REVIEW:
      let new_reviews_open = []
      for (let i = 0, len = state.reviews.length; i < len; i++) {
        if (state.reviews[i].id === action.id) {
          new_reviews_open.push({
            ...state.reviews[i],
            is_open: true
          })
        } else {
          new_reviews_open.push({
            ...state.reviews[i],
          })
        }
      }
      return {
        ...state,
        reviews: new_reviews_open
      }
      case CLOSE_REVIEW:
      let new_reviews_close = []
      for (let i = 0, len = state.reviews.length; i < len; i++) {
        if (state.reviews[i].id === action.id) {
          new_reviews_close.push({
            ...state.reviews[i],
            is_open: false
          })
        } else {
          new_reviews_close.push({
            ...state.reviews[i],
          })
        }
      }
      return {
        ...state,
        reviews: new_reviews_close
      }
    default:
      return state
  }
}

export default actionsReducer
