export const SUCCESS_ALERT = "SUCCESS_ALERT"
export const INFO_ALERT    = "INFO_ALERT"
export const ERROR_ALERT   = "ERROR_ALERT"
export const CLEAR_ALERT   = "CLEAR_ALERT"
